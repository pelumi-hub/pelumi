export type Severity = 'safe' | 'low' | 'medium' | 'high' | 'critical';

export type MalwareType = 
  | 'macro_virus' 
  | 'embedded_script' 
  | 'ransomware' 
  | 'trojan' 
  | 'spyware'
  | 'unknown';

export interface FileMetadata {
  name: string;
  size: number;
  type: string;
  lastModified: Date;
  isEncrypted: boolean;
}

export interface FileScanResult {
  malwareDetected: boolean;
  severity: Severity;
  threatPercentage: number;
  malwareType: MalwareType;
  detectionDetails: string;
  scanDate: Date;
}