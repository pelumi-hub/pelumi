import React from 'react';
import { Shield } from 'lucide-react';
import Header from './components/Header';
import Footer from './components/Footer';
import ScannerPage from './pages/ScannerPage';

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Header />
      <main className="flex-grow">
        <ScannerPage />
      </main>
      <Footer />
    </div>
  );
}

export default App;