import React from 'react';
import { Shield } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white py-8 px-6">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <Shield className="h-6 w-6 text-blue-300" />
            <span className="text-xl font-bold">DocGuard</span>
          </div>
          <div className="text-sm text-blue-200">
            &copy; {new Date().getFullYear()} DocGuard. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;