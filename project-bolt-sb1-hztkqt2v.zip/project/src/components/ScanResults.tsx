import React from 'react';
import { CheckCircle, AlertTriangle, AlertOctagon, Download, Share2, Printer } from 'lucide-react';
import { FileScanResult, FileMetadata, MalwareType } from '../types/scanner';
import FileMetadataDisplay from './FileMetadataDisplay';
import SeverityBadge from './SeverityBadge';
import ThreatMeter from './ThreatMeter';

interface ScanResultsProps {
  result: FileScanResult;
  fileMetadata: FileMetadata | null;
}

const ScanResults: React.FC<ScanResultsProps> = ({ result, fileMetadata }) => {
  const getStatusIcon = () => {
    if (!result.malwareDetected) {
      return <CheckCircle className="h-10 w-10 text-green-500" />;
    }
    
    switch (result.severity) {
      case 'critical':
      case 'high':
        return <AlertOctagon className="h-10 w-10 text-red-500" />;
      case 'medium':
      case 'low':
        return <AlertTriangle className="h-10 w-10 text-yellow-500" />;
      default:
        return <AlertTriangle className="h-10 w-10 text-yellow-500" />;
    }
  };
  
  const getStatusTitle = () => {
    if (!result.malwareDetected) {
      return "No Threats Detected";
    }
    
    switch (result.severity) {
      case 'critical':
        return "Critical Threat Detected!";
      case 'high':
        return "High Risk Threat Detected!";
      case 'medium':
        return "Medium Risk Threat Detected";
      case 'low':
        return "Low Risk Threat Detected";
      default:
        return "Potential Threat Detected";
    }
  };
  
  const getStatusDescription = () => {
    if (!result.malwareDetected) {
      return "Your document appears to be safe. No malicious content was detected during our scan.";
    }
    
    const encryptionNote = fileMetadata?.isEncrypted 
      ? " Note: This file is encrypted, which limited our ability to perform a complete scan."
      : "";
    
    switch (result.severity) {
      case 'critical':
        return `We detected a serious security threat in this document. We strongly recommend not opening this file.${encryptionNote}`;
      case 'high':
        return `We detected a high-risk threat in this document. Opening this file could compromise your system.${encryptionNote}`;
      case 'medium':
        return `We detected a potentially harmful element in this document. Proceed with caution.${encryptionNote}`;
      case 'low':
        return `We detected a low-risk issue in this document. The file may be safe, but review the details below.${encryptionNote}`;
      default:
        return `We detected a potential security concern in this document. Review the details below.${encryptionNote}`;
    }
  };

  const formatMalwareType = (type: MalwareType): string => {
    switch (type) {
      case 'macro_virus':
        return 'Macro Virus';
      case 'embedded_script':
        return 'Embedded Script';
      case 'ransomware':
        return 'Ransomware';
      case 'trojan':
        return 'Trojan';
      case 'spyware':
        return 'Spyware';
      default:
        return type;
    }
  };
  
  return (
    <div className="w-full">
      <div className="text-center mb-8 pt-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full mb-4">
          {getStatusIcon()}
        </div>
        <h2 className="text-2xl font-bold mb-2">Scan Complete</h2>
        <h3 className={`text-xl font-semibold mb-3 ${
          !result.malwareDetected ? 'text-green-600' : 
          result.severity === 'critical' ? 'text-red-600' :
          result.severity === 'high' ? 'text-red-500' :
          result.severity === 'medium' ? 'text-orange-500' :
          'text-yellow-500'
        }`}>
          {getStatusTitle()}
        </h3>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          {getStatusDescription()}
        </p>
      </div>
      
      {fileMetadata && (
        <div className="mb-8">
          <FileMetadataDisplay metadata={fileMetadata} />
        </div>
      )}
      
      <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="p-5 border-b border-gray-200 bg-gray-50">
          <h3 className="text-lg font-semibold">Security Scan Results</h3>
        </div>
        
        <div className="p-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Threat Status</h4>
                <div className="flex items-center">
                  <SeverityBadge severity={result.malwareDetected ? result.severity : 'safe'} />
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Threat Level</h4>
                <ThreatMeter percentage={result.threatPercentage} />
              </div>
              
              {result.malwareDetected && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Malware Type</h4>
                  <p className="text-lg font-medium text-gray-800">
                    {formatMalwareType(result.malwareType)}
                  </p>
                </div>
              )}
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Scan Details</h4>
              <div className="bg-gray-50 rounded-lg p-4">
                <ul className="space-y-3">
                  <li className="flex justify-between">
                    <span className="text-gray-600">Scan Date:</span>
                    <span className="font-medium">{new Date().toLocaleDateString()}</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Scan Method:</span>
                    <span className="font-medium">AI + Static Analysis</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Encryption Detected:</span>
                    <span className="font-medium">
                      {fileMetadata?.isEncrypted ? 'Yes' : 'No'}
                    </span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-gray-600">Scan Status:</span>
                    <span className="font-medium text-green-600">Complete</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {result.malwareDetected && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h4 className="text-sm font-medium text-gray-500 mb-3">Threat Details</h4>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-gray-700 mb-4">
                  {result.detectionDetails}
                </p>
                
                {fileMetadata?.isEncrypted && (
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                    <p className="text-sm text-yellow-700">
                      <strong>Note:</strong> This file is encrypted, which limited our ability to perform a complete scan. 
                      The assessment is based on available metadata and non-encrypted parts of the document.
                    </p>
                  </div>
                )}
                
                <h5 className="text-sm font-medium text-gray-600 mb-2">Recommendations:</h5>
                <ul className="list-disc pl-5 text-sm text-gray-700 space-y-1">
                  {result.severity === 'critical' || result.severity === 'high' ? (
                    <>
                      <li>Do not open this document</li>
                      <li>Delete the file immediately</li>
                      <li>Scan your system with an antivirus program</li>
                      <li>Contact your IT department</li>
                    </>
                  ) : result.severity === 'medium' ? (
                    <>
                      <li>Open this document only if you trust the source</li>
                      <li>Disable macros before opening</li>
                      <li>Consider using a sandbox environment</li>
                    </>
                  ) : (
                    <>
                      <li>The risk is low, but proceed with caution</li>
                      <li>Ensure your antivirus is up to date</li>
                    </>
                  )}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex flex-wrap gap-3">
        <button className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
          <Download className="h-4 w-4 mr-2" />
          Download Report
        </button>
        <button className="flex items-center px-4 py-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg transition-colors">
          <Share2 className="h-4 w-4 mr-2" />
          Share Results
        </button>
        <button className="flex items-center px-4 py-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg transition-colors">
          <Printer className="h-4 w-4 mr-2" />
          Print Report
        </button>
      </div>
    </div>
  );
};

export default ScanResults;