import React from 'react';

interface ThreatMeterProps {
  percentage: number;
}

const ThreatMeter: React.FC<ThreatMeterProps> = ({ percentage }) => {
  const getColor = () => {
    if (percentage < 20) return 'bg-green-500';
    if (percentage < 40) return 'bg-yellow-400';
    if (percentage < 60) return 'bg-orange-500';
    if (percentage < 80) return 'bg-red-500';
    return 'bg-red-600';
  };
  
  const getLabel = () => {
    if (percentage < 20) return 'Very Low';
    if (percentage < 40) return 'Low';
    if (percentage < 60) return 'Medium';
    if (percentage < 80) return 'High';
    return 'Very High';
  };
  
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-lg font-semibold">{percentage}%</span>
        <span className="text-sm text-gray-600">{getLabel()}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className={`h-2.5 rounded-full ${getColor()}`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      <div className="flex justify-between text-xs text-gray-500 mt-1">
        <span>Safe</span>
        <span>Dangerous</span>
      </div>
    </div>
  );
};

export default ThreatMeter;