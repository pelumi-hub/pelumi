import React from 'react';
import { Shield } from 'lucide-react';

interface ScanningProgressProps {
  progress: number;
}

const ScanningProgress: React.FC<ScanningProgressProps> = ({ progress }) => {
  return (
    <div className="w-full">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-4 relative">
          <Shield className={`h-10 w-10 text-blue-600 animate-pulse`} />
          <div className="absolute inset-0">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <circle 
                className="text-blue-100 stroke-current" 
                strokeWidth="6" 
                cx="50" 
                cy="50" 
                r="44" 
                fill="none" 
              />
              <circle 
                className="text-blue-600 stroke-current" 
                strokeWidth="6" 
                strokeLinecap="round" 
                cx="50" 
                cy="50" 
                r="44" 
                fill="none"
                strokeDasharray="276.5"
                strokeDashoffset={276.5 - (276.5 * progress) / 100}
                transform="rotate(-90 50 50)"
              />
            </svg>
          </div>
        </div>
        <h3 className="text-xl font-bold text-blue-900 mb-2">Scanning Document</h3>
        <p className="text-gray-600 mb-6">
          Our AI is analyzing your document for potential security threats...
        </p>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
        <div 
          className="bg-blue-600 h-2.5 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      
      <div className="flex justify-between items-center text-sm text-gray-600">
        <span>{progress}% Complete</span>
        <span>
          {progress < 30 ? 'Analyzing file structure...' : 
           progress < 60 ? 'Scanning for malicious patterns...' : 
           progress < 90 ? 'Checking for embedded threats...' : 
           'Finalizing security report...'}
        </span>
      </div>
      
      <div className="mt-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="h-2 bg-blue-200 rounded animate-pulse mb-2"></div>
            <div className="h-2 bg-blue-200 rounded animate-pulse w-3/4"></div>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="h-2 bg-blue-200 rounded animate-pulse mb-2"></div>
            <div className="h-2 bg-blue-200 rounded animate-pulse w-1/2"></div>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="h-2 bg-blue-200 rounded animate-pulse mb-2"></div>
            <div className="h-2 bg-blue-200 rounded animate-pulse w-2/3"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScanningProgress;