import React, { useRef, useState } from 'react';
import { FileText, Upload, Shield, AlertCircle } from 'lucide-react';
import { FileMetadata } from '../types/scanner';
import FileMetadataDisplay from './FileMetadataDisplay';

interface FileUploaderProps {
  onFileSelected: (file: File) => void;
  onStartScan: () => void;
  selectedFile: File | null;
  fileMetadata: FileMetadata | null;
}

const FileUploader: React.FC<FileUploaderProps> = ({ 
  onFileSelected, 
  onStartScan, 
  selectedFile,
  fileMetadata
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onFileSelected(files[0]);
    }
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      onFileSelected(files[0]);
    }
  };
  
  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const acceptedFileTypes = ".pdf,.docx,.txt";
  
  return (
    <div className="w-full">
      <div 
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all duration-200 ${
          isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : selectedFile 
              ? 'border-green-500 bg-green-50' 
              : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={selectedFile ? undefined : triggerFileInput}
      >
        <input 
          type="file" 
          ref={fileInputRef}
          className="hidden" 
          onChange={handleFileChange}
          accept={acceptedFileTypes}
        />
        
        {!selectedFile ? (
          <>
            <div className="flex justify-center mb-4">
              <Upload className="h-12 w-12 text-blue-500" />
            </div>
            <h3 className="text-lg font-medium mb-2">Drag and drop your document here</h3>
            <p className="text-gray-500 mb-4">or click to browse</p>
            <p className="text-sm text-gray-400">
              Supported file types: PDF, DOCX, TXT
            </p>
          </>
        ) : (
          <div className="flex flex-col items-center">
            <FileText className="h-12 w-12 text-green-500 mb-4" />
            <h3 className="text-lg font-medium mb-2">File selected</h3>
            <p className="text-gray-600 mb-1 font-medium">{selectedFile.name}</p>
            <p className="text-sm text-gray-500 mb-4">
              {(selectedFile.size / 1024).toFixed(2)} KB
            </p>
            
            <button 
              className="text-sm text-blue-500 hover:text-blue-700 transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                triggerFileInput();
              }}
            >
              Select a different file
            </button>
          </div>
        )}
      </div>
      
      {fileMetadata && (
        <div className="mt-6">
          <FileMetadataDisplay metadata={fileMetadata} />
        </div>
      )}
      
      {selectedFile && (
        <div className="mt-6">
          <button
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors flex items-center justify-center"
            onClick={onStartScan}
          >
            <Shield className="mr-2 h-5 w-5" />
            Start Security Scan
          </button>
          
          {fileMetadata?.isEncrypted && (
            <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-md p-4 flex items-start">
              <AlertCircle className="text-yellow-500 h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-yellow-700">
                This file appears to be encrypted. We'll analyze metadata and accessible parts, but detailed inspection may be limited.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FileUploader;