import React from 'react';
import { CheckCircle, AlertTriangle, AlertCircle, AlertOctagon } from 'lucide-react';
import { Severity } from '../types/scanner';

interface SeverityBadgeProps {
  severity: Severity;
}

const SeverityBadge: React.FC<SeverityBadgeProps> = ({ severity }) => {
  const getStyles = () => {
    switch (severity) {
      case 'safe':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'low':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'medium':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'critical':
        return 'bg-red-100 text-red-900 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  
  const getIcon = () => {
    switch (severity) {
      case 'safe':
        return <CheckCircle className="h-4 w-4 mr-1.5" />;
      case 'low':
        return <AlertTriangle className="h-4 w-4 mr-1.5" />;
      case 'medium':
        return <AlertCircle className="h-4 w-4 mr-1.5" />;
      case 'high':
        return <AlertOctagon className="h-4 w-4 mr-1.5" />;
      case 'critical':
        return <AlertOctagon className="h-4 w-4 mr-1.5" />;
      default:
        return <AlertTriangle className="h-4 w-4 mr-1.5" />;
    }
  };
  
  const getLabel = () => {
    switch (severity) {
      case 'safe':
        return 'Safe';
      case 'low':
        return 'Low Risk';
      case 'medium':
        return 'Medium Risk';
      case 'high':
        return 'High Risk';
      case 'critical':
        return 'Critical Risk';
      default:
        return 'Unknown';
    }
  };
  
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-sm font-medium border ${getStyles()}`}>
      {getIcon()}
      {getLabel()}
    </span>
  );
};

export default SeverityBadge;