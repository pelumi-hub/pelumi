import React from 'react';
import { Calendar, FileType, Lock, Unlock, FileText } from 'lucide-react';
import { FileMetadata } from '../types/scanner';

interface FileMetadataDisplayProps {
  metadata: FileMetadata;
}

const FileMetadataDisplay: React.FC<FileMetadataDisplayProps> = ({ metadata }) => {
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(2) + ' KB';
    else return (bytes / 1048576).toFixed(2) + ' MB';
  };
  
  const formatFileType = (type: string): string => {
    if (type.includes('pdf')) return 'PDF Document';
    if (type.includes('docx')) return 'Word Document';
    if (type.includes('text/plain')) return 'Text File';
    return type;
  };
  
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
      <h3 className="text-sm font-medium text-gray-700 mb-3">File Information</h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="flex items-start">
          <FileText className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
          <div>
            <p className="text-xs text-gray-500">Filename</p>
            <p className="text-sm font-medium text-gray-800">{metadata.name}</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <FileType className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
          <div>
            <p className="text-xs text-gray-500">File Type</p>
            <p className="text-sm font-medium text-gray-800">{formatFileType(metadata.type)}</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <Calendar className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
          <div>
            <p className="text-xs text-gray-500">Last Modified</p>
            <p className="text-sm font-medium text-gray-800">{formatDate(metadata.lastModified)}</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="h-5 w-5 flex-shrink-0 mr-2 mt-0.5">
            {metadata.isEncrypted 
              ? <Lock className="h-5 w-5 text-yellow-500" /> 
              : <Unlock className="h-5 w-5 text-green-500" />
            }
          </div>
          <div>
            <p className="text-xs text-gray-500">Encryption Status</p>
            <p className={`text-sm font-medium ${metadata.isEncrypted ? 'text-yellow-600' : 'text-green-600'}`}>
              {metadata.isEncrypted ? 'Encrypted' : 'Not Encrypted'}
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-3 pt-3 border-t border-gray-200">
        <div className="flex items-center">
          <span className="text-xs text-gray-500 mr-2">File Size:</span>
          <span className="text-sm font-medium text-gray-800">{formatFileSize(metadata.size)}</span>
        </div>
      </div>
    </div>
  );
};

export default FileMetadataDisplay;