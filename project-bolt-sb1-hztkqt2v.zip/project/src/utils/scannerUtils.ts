import { FileScanResult, MalwareType, Severity } from '../types/scanner';

type ProgressCallback = (progress: number) => void;
type CompletionCallback = (result: FileScanResult) => void;

export const simulateScan = (
  file: File,
  onProgress: ProgressCallback,
  onComplete: CompletionCallback
) => {
  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.floor(Math.random() * 5) + 1;
    
    if (progress > 100) {
      progress = 100;
      clearInterval(interval);
      onProgress(progress);
      
      // Simulate a short delay before returning results
      setTimeout(() => {
        onComplete(generateScanResult(file));
      }, 500);
    } else {
      onProgress(progress);
    }
  }, 200);
};

const generateScanResult = (file: File): FileScanResult => {
  // In a real application, this would be based on actual analysis
  // For this demo, we'll randomize the results
  
  // 30% chance of detecting malware
  const malwareDetected = Math.random() < 0.3;
  
  if (!malwareDetected) {
    return {
      malwareDetected: false,
      severity: 'safe',
      threatPercentage: Math.floor(Math.random() * 10),
      malwareType: 'unknown',
      detectionDetails: 'No malicious content detected in this document.',
      scanDate: new Date()
    };
  }
  
  // If malware is detected, determine its severity
  const randomValue = Math.random();
  let severity: Severity;
  let threatPercentage: number;
  
  if (randomValue < 0.2) {
    severity = 'critical';
    threatPercentage = 80 + Math.floor(Math.random() * 20);
  } else if (randomValue < 0.4) {
    severity = 'high';
    threatPercentage = 60 + Math.floor(Math.random() * 20);
  } else if (randomValue < 0.7) {
    severity = 'medium';
    threatPercentage = 40 + Math.floor(Math.random() * 20);
  } else {
    severity = 'low';
    threatPercentage = 20 + Math.floor(Math.random() * 20);
  }
  
  // Determine malware type
  const malwareTypes: MalwareType[] = [
    'macro_virus',
    'embedded_script',
    'ransomware',
    'trojan',
    'spyware'
  ];
  
  const malwareType = malwareTypes[Math.floor(Math.random() * malwareTypes.length)];
  
  // Generate detection details based on malware type
  let detectionDetails = '';
  
  switch (malwareType) {
    case 'macro_virus':
      detectionDetails = 'Suspicious macro detected in the document. This macro contains code that could execute when the document is opened, potentially allowing unauthorized access to your system.';
      break;
    case 'embedded_script':
      detectionDetails = 'Potentially malicious script embedded in the document. This script could execute automatically and compromise your system security.';
      break;
    case 'ransomware':
      detectionDetails = 'Code patterns consistent with ransomware detected. This document may contain elements that could encrypt your files and demand payment for recovery.';
      break;
    case 'trojan':
      detectionDetails = 'Suspicious code detected that may attempt to install unwanted software on your system. This could provide unauthorized access to your computer.';
      break;
    case 'spyware':
      detectionDetails = 'Potential spyware components detected in this document. These components may attempt to collect sensitive information from your system.';
      break;
    default:
      detectionDetails = 'Suspicious code detected in the document that could pose a security risk.';
  }
  
  return {
    malwareDetected,
    severity,
    threatPercentage,
    malwareType,
    detectionDetails,
    scanDate: new Date()
  };
};