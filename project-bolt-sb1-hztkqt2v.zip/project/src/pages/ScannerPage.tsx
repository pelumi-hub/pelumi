import React, { useState } from 'react';
import FileUploader from '../components/FileUploader';
import ScanningProgress from '../components/ScanningProgress';
import ScanResults from '../components/ScanResults';
import { FileScanResult, FileMetadata } from '../types/scanner';
import { simulateScan } from '../utils/scannerUtils';

const ScannerPage: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [scanning, setScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [scanResult, setScanResult] = useState<FileScanResult | null>(null);

  const handleFileSelected = (selectedFile: File) => {
    setFile(selectedFile);
    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type || getFileTypeFromName(selectedFile.name),
      lastModified: new Date(selectedFile.lastModified),
      isEncrypted: detectIfEncrypted(selectedFile)
    });
    
    // Reset previous scan results
    setScanResult(null);
    setScanning(false);
    setScanProgress(0);
  };

  const handleStartScan = () => {
    if (!file) return;
    
    setScanning(true);
    setScanProgress(0);
    
    simulateScan(file, (progress) => {
      setScanProgress(progress);
    }, (result) => {
      setScanResult(result);
      setScanning(false);
    });
  };

  const getFileTypeFromName = (fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase() || '';
    switch (extension) {
      case 'pdf': return 'application/pdf';
      case 'docx': return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'txt': return 'text/plain';
      default: return 'application/octet-stream';
    }
  };
  
  const detectIfEncrypted = (file: File): boolean => {
    // In a real app, we would use heuristics or attempt to parse the file
    // For this demo, we'll randomly determine if a file is "encrypted"
    return Math.random() > 0.7;
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
          <div className="p-6 md:p-8">
            <h2 className="text-2xl font-bold text-blue-900 mb-6">Document Security Scanner</h2>
            <p className="text-gray-600 mb-8">
              Upload a document (PDF, DOCX, TXT) to scan for potential security threats and malware.
              Our AI-powered system will analyze the document and provide a comprehensive security report.
            </p>
            
            {!scanning && !scanResult && (
              <FileUploader 
                onFileSelected={handleFileSelected} 
                onStartScan={handleStartScan}
                selectedFile={file}
                fileMetadata={fileMetadata}
              />
            )}
            
            {scanning && (
              <ScanningProgress progress={scanProgress} />
            )}
            
            {scanResult && (
              <ScanResults result={scanResult} fileMetadata={fileMetadata} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScannerPage;